# Ash Warden — Free Animated Pixel Art Enemy

## Project settings

- **Suggested URL:** `ash-warden-free-pixel-art-enemy`
- **Classification:** Assets
- **Kind:** Downloadable
- **Release status:** Released
- **Pricing:** $0 / pay what you want
- **Upload:** `ash-warden-elemental-v1.zip`
- **Cover:** `previews/itch_cover_final_630x500.png`
- **Layout:** Two columns

## Short description

Free animated fire elemental enemy with five actions, separate projectile, and engine-ready PNGs.

## Page description

**Ash Warden** is a free animated fire elemental for top-down fantasy RPGs, action RPGs, dungeon crawlers, prototypes, and game jams.

The pack uses a dark basalt-and-ember design with a clear right-facing silhouette. Every action is supplied as individual transparent PNG frames and as an animation spritesheet.

## Included

- Idle animation — 4 frames
- Move animation — 4 frames
- Attack animation — 4 frames
- Hit animation — 4 frames
- Death animation — 4 frames
- Separate ember projectile — 4 frames
- Individual 96×96 RGBA PNG frames
- Per-animation spritesheets
- Complete spritesheet
- Manifest, style profile, license, and import notes

The projectile is intentionally separated from the attack so it can be spawned, timed, and moved independently inside the game engine.

## Technical details

- Logical grid: 32×32
- Frame canvas: 96×96
- Direction: screen-right
- Pivot: bottom-center
- Format: transparent PNG
- Recommended filtering: nearest / point
- Compatible structure for Unity, Godot, Unreal, and other 2D engines

## License

The assets may be used and modified in personal and commercial projects. Attribution is optional. Redistribution or resale of the raw or modified asset files as standalone assets is not allowed. Team and contractor use is permitted under the conditions in the included `license.txt`.

## Support the collection

This starter enemy is free. Optional donations help fund **Elemental Enemies Vol. 1**, a future paid pack planned at **US$5** with fire, ice, wind, and thunder enemies. Each elemental will have its own silhouette, animations, attacks, death sequence, effects, and projectile—not simple recolors.

Follow the creator page to receive the release announcement and future free updates.

## Generative AI disclosure

This asset pack contains AI-assisted graphics. The concept and master artwork were generated with generative AI, then curated, background-cleaned, separated into a consistent grid, resized with nearest-neighbor processing, organized, documented, and technically validated. The store page must select the appropriate generative-AI disclosure option before publication.

## Suggested tags

`Pixel Art`, `2D`, `Top-Down`, `Fantasy`, `Enemies`, `Monsters`, `Sprites`, `Action RPG`, `Role Playing`, `Asset Pack`

## Suggested theme

- Page background: `#17110D`
- Content background: `#211710`
- Primary text: `#FFF2D6`
- Links and buttons: `#FF8A1E`
- Muted text: `#C8B49A`

## Media order

1. `previews/ash_warden_attack.gif`
2. `previews/ash_warden_move.gif`
3. `previews/ash_warden_death.gif`
4. `previews/ember_projectile.gif`
5. `previews/ash_warden_preview.png`

Keep the page in Draft while checking the cover, GIF playback, download, license, and AI disclosure. Publish it after the animations have been tested at their suggested FPS inside a game engine.
