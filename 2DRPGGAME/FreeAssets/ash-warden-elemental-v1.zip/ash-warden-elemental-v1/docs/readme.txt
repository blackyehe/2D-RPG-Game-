ASH WARDEN ELEMENTAL - VERSION 1.1.1 FREE EDITION

Original 2D pixel-art enemy pack for top-down fantasy RPGs.

CONTENTS
- 1 Ash Warden enemy facing screen-right.
- 5 character animations: idle, move, attack, hit, death.
- 4 frames per character animation.
- 1 separate ember projectile animation with 4 frames.
- Individual RGBA PNG frames.
- One spritesheet per animation.
- One complete 4-column x 6-row spritesheet.
- One store preview on a dark background.
- One 630 x 500 itch.io cover image.
- Six animated GIF previews for the store page.
- A complete itch.io publication sheet in docs/itch_page.md.

TECHNICAL SPECIFICATION
- Logical grid unit: 32 x 32 pixels.
- Frame canvas: 96 x 96 pixels (3 x 3 logical units).
- Animation spritesheets: 384 x 96 pixels.
- Complete spritesheet: 384 x 576 pixels.
- Pivot: bottom-center at (48, 95) on each 96 x 96 frame.
- Direction: screen-right.
- Format: PNG, RGBA transparency, sRGB.
- Filtering: nearest/point; disable texture smoothing.

ROW ORDER IN COMPLETE SPRITESHEET
0 idle
1 move
2 attack
3 hit
4 death
5 ember projectile

SUGGESTED PLAYBACK
- idle: 6 fps, loop
- move: 8 fps, loop
- attack: 10 fps, play once
- hit: 10 fps, play once
- death: 7 fps, play once and hold final frame
- ember projectile: 12 fps, loop or play once according to gameplay

ENGINE NOTES
- Unity: Sprite Mode Multiple, Pixels Per Unit 32, Filter Mode Point, no compression.
- Godot: use nearest texture filtering and 4 horizontal frames per animation.
- Unreal: use 2D pixel-art texture settings, nearest filtering, and a bottom-center pivot.

The attack sheet contains body action only. The ember projectile is supplied separately so the game engine can spawn and move it independently.

PUBLICATION NOTE
This free edition is intended to be listed as free / pay what you want. The future paid Elemental Enemies Vol. 1 is planned to add fire, ice, wind, and thunder enemies with substantially different silhouettes, attacks, deaths, effects, and projectiles.
