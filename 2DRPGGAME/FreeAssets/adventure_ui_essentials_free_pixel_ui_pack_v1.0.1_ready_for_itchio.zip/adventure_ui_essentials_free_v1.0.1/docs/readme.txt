ADVENTURE UI ESSENTIALS — FREE PIXEL UI PACK
Version 1.0.1
Publisher: Obssidian Art

CONTENTS
- 3 coordinated UI themes: Parchment, Ocean and Woodland
- 3 nine-slice panel sheets using a 16x16 base grid
- 6 ready-made panels: 96x64 and 160x96
- 36 blank buttons: 3 widths, 4 states and 3 themes
- 44 resource bars: health, mana, stamina and experience, levels 0-10
- 40 functional icons at 16x16
- 24 keyboard, mouse and gamepad prompts at 24x24
- 8 cursor icons at 16x16
- 4 inventory-slot states at 32x32
- 11 consolidated spritesheets

TOTAL
- 165 individual UI assets
- 176 PNG files including spritesheets

FORMAT
- PNG RGBA with true transparency
- Native pixel-art resolution
- No embedded marketing text in usable assets
- Recommended filtering: nearest-neighbor / point
- Recommended scaling: whole-number multiples

NINE-SLICE PANELS
Each 48x48 sheet contains a 3x3 arrangement of 16x16 regions:
top-left, top, top-right
left, center, right
bottom-left, bottom, bottom-right

See nine_slice_guide.json for exact rectangles.

BUTTON STATES
Normal, hover, pressed and disabled.
Buttons are blank so developers can use any language or game font.

RESOURCE BARS
Files 00 through 10 represent 0% through 100% in 10% increments.

LICENSE
Personal and commercial use is permitted. Attribution is optional.
Redistribution as standalone assets is prohibited. Read license.txt.

SUGGESTED CREDIT
Adventure UI Essentials by Obssidian Art
