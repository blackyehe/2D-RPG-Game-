==================================================
Basic Attack FX
Version 1.0
Created by Moonpetal Teatime
==================================================

Thank you for downloading this asset pack!

Contents
----------------------------------

📁 Frame/
Individual PNG frames with transparent background (RGBA).

📁 Frame_blackbg/
Individual PNG frames with solid black background (#000000).

🖼 sprite-sheet.png
Sprite sheet with transparent background.

⬛ sprite-sheet_blackbg.png
Sprite sheet with solid black background.

🎬 animation.gif
Looping animation preview.

🎨 sprite-sheet.psd
Editable Photoshop sprite sheet.

🎞 frames_layered.psd
Editable Photoshop file with every frame on a separate layer.

Compatibility
----------------------------------

This asset can be used with most game engines, including:

• Unity
• Godot
• Unreal Engine
• GameMaker
• RPG Maker
• Any engine that supports PNG sprite sheets

License
----------------------------------

Please read LICENSE.txt before using this asset.

Support
----------------------------------

If you have any questions or encounter any issues,
please contact us through our itch.io page.

Thank you for supporting Moonpetal Teatime!

==================================================